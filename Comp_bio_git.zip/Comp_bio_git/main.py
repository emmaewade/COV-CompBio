from Bio.SeqRecord import SeqRecord
from Bio import SeqIO
import squiggle
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.pyplot import figure
import seaborn as sb
import json

Beta_covid19 = SeqIO.read('Betacoronaviru.fasta', 'fasta')
SARS_human = SeqIO.read('SARS_2012.fasta', 'fasta')
MERS_human = SeqIO.read('MERS.fasta', 'fasta')
Ebola = SeqIO.read('Ebola.fasta', 'fasta')
Bat_covid19 = SeqIO.read('Bat_cov.fasta', 'fasta')

series1 = squiggle.squiggle.transform(Beta_covid19, method='gates', bar=False)
df = pd.DataFrame(series1)
df1 = df.T
df1 = df1.rename(columns={0: 'x', 1: 'y'})

series2 = squiggle.squiggle.transform(SARS_human, method='gates', bar=False)
dfn = pd.DataFrame(series2)
df2 = dfn.T
df2 = df2.rename(columns={0: 'x', 1: 'y'})

series3 = squiggle.squiggle.transform(MERS_human, method='gates', bar=False)
dfn1 = pd.DataFrame(series3)
df3 = dfn1.T
df3 = df3.rename(columns={0: 'x', 1: 'y'})

series4 = squiggle.squiggle.transform(Ebola, method='gates', bar=False)
dfn2 = pd.DataFrame(series4)
df4 = dfn2.T
df4 = df4.rename(columns={0: 'x', 1: 'y'})

series5 = squiggle.squiggle.transform(Bat_covid19, method='gates', bar=False)
dfn3 = pd.DataFrame(series5)
df5 = dfn3.T
df5 = df5.rename(columns={0: 'x', 1: 'y'})

# plotting the data
fig = plt.figure(figsize=(8, 8))
fig.subplots_adjust(hspace=.4)
fig.suptitle('comparing 2D DNA sequences of Covid-19 vs other outbreaks', fontsize=14)

ax1 = fig.add_subplot(2, 3, 1)
ax1.grid()
ax1.plot(df1['x'], df1['y'], 'r')
ax1.set_title('Beta_covid19\n England_1')
ax1.tick_params(axis='both', which='major')
ax1.set_xlabel('C-G axis')
ax1.set_ylabel('A-T axis')

ax2 = fig.add_subplot(2, 3, 2)
ax2.grid()
ax2.plot(df2['x'], df2['y'], 'b')
ax2.set_title('SARS\n Human En_06912')
ax2.tick_params(axis='both', which='major')

ax3 = fig.add_subplot(2, 3, 3)
ax3.grid()
ax3.plot(df3['x'], df3['y'], 'g')
ax3.set_title('MERS\n HCov-EMC/2012')
ax3.tick_params(axis='both', which='major')
ax3.set_xlabel('C-G axis')
ax3.set_ylabel('A-T axis')

ax4 = fig.add_subplot(2, 3, 4)
ax4.grid()
ax4.plot(df4['x'], df4['y'], 'k')
ax4.set_title('Ebola')
ax4.tick_params(axis='both', which='major')

ax5 = fig.add_subplot(2, 3, 5)
ax5.grid()
ax5.plot(df5['x'], df5['y'], 'g')
ax5.set_title('Bat_covid19\n BatCov_complete_genome')
ax5.tick_params(axis='both', which='major')
ax5.set_xlabel('C-G axis')
ax5.set_ylabel('A-T axis')

fig.tight_layout()
fig.subplots_adjust(top=0.87)

plt.savefig('twobytwo.png', bbox_inches='tight')

plt.show()

data = open('virus_all_genes.json')
virus_genes = json.load(data)
genes_name = ['ORF1ab', 'Spike', 'Envelop', 'Membrane', 'Nucleo-capsid']

# traversing through the amino acid seq to visualize its length 
for virus in virus_genes:
    print(virus)
    virus_length = []
    for gene in virus_genes[virus]:
        print(gene, len(virus_genes[virus][gene]))
        virus_length.append(len(virus_genes[virus][gene]))
    # print(virus)
    plt.plot(genes_name, virus_length, label = '%s data' % virus)

    plt.ylabel('amino_acid length')
    plt.xlabel('Proteins')
    plt.title('Comparative_genome_length')
    print("\n")


plt.legend()

plt.show()




